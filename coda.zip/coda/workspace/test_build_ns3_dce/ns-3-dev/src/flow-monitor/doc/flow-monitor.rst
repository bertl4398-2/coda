Flow Monitor
------------

*Placeholder chapter*

This feature was added as contributed code (``src/contrib``) in
*ns-3.6* and to the main distribution (``src/flow-monitor``) for
*ns-3.7*. A paper on this feature is published in the proceedings of
NSTools: `<http://www.nstools.org/techprog.shtml>`_.
